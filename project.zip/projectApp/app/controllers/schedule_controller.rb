class ScheduleController < ApplicationController
  def index
  end
end
